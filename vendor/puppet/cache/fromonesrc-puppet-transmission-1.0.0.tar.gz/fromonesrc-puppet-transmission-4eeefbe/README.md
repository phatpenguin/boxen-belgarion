# Transmission
[Transmission](http://www.transmissionbt.com/) BitTorrent client for the
Mac

## Usage

```puppet
include transmission
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
