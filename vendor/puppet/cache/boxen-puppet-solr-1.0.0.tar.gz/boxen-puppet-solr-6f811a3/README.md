# SOLR Puppet Module for Boxen

## Usage

```puppet
include solr
```

## Required Puppet Modules

* boxen
* homebrew
* java
* stdlib
