# XPDF Puppet Module for Boxen

## Usage

```puppet
include xpdf
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
