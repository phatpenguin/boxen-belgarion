# Erlang Puppet Module for Boxen

Install the [Erlang](http://www.erlang.org) programming language.

## Usage

```puppet
include erlang
```

## Required Puppet Modules

* `autoconf`
* `boxen`
* `libtool`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
